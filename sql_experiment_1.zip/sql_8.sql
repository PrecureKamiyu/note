select c.name AS category_name
, c.category_id AS category_id
, count(f.film_id) AS total_films
from film AS f
inner join film_category AS fc ON f.film_id = fc.film_id
inner join category AS c ON fc.category_id = c.category_id
group by c.category_id;