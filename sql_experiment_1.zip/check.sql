select i.store_id as store_id
from film as f
inner join inventory as i on f.film_id = i.film_id
where f.film_id = 100;