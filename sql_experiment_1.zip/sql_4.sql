select f.film_id AS id, f.title AS title, sum(p.amount) AS total_sales
from payment AS p
inner join rental AS r ON p.rental_id = r.rental_id
inner join inventory AS i ON r.inventory_id = i.inventory_id
inner join film AS f ON i.film_id = f.film_id
group by f.film_id
order by sum(p.amount) DESC
limit 1;