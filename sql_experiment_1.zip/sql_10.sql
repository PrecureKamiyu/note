select c.first_name AS first_name
, c.last_name AS last_name
, max(UNIX_TIMESTAMP(r.return_date) - UNIX_TIMESTAMP(r.rental_date)) AS max_rent_time
from rental AS r
inner join customer AS c ON r.customer_id = c.customer_id
group by r.rental_id
order by max(r.return_date - r.rental_date) DESC
limit 2;