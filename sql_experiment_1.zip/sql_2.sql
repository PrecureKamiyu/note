select title from film as f
, category as c
, fiml_category as fc
where f.film_id = fc.film_id
and fc.category_id = c.category_id
and left(f.title, 1) = 'A';