delete from rental
where customer_id = 601;

delete from customer
where customer_id = 601;

-- check
select count(*) from customer
where customer_id = 601;