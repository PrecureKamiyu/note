select c.first_name AS first_name
, c.last_name AS last_name
from customer AS c
inner join rental AS r ON c.customer_id = r.customer_id
inner join inventory AS i ON r.inventory_id = i.inventory_id
inner join film AS f ON i.film_id = f.film_id
where NOT f.title = 'NATRUAL STOCK'
group by c.customer_id;

select c.first_name AS first_name
, c.last_name AS last_name
from customer AS c
where not exists (
    select *
    from rental AS r
    inner join inventory AS i ON r.inventory_id = i.inventory_id
    inner join film AS f ON i.film_id = f.film_id
    where f.film_id = 'NATRUAL STOCK' and r.customer_id = c.customer_id
);