insert into customer (store_id, first_name, last_name, address_id, create_date, last_update)
values(1, 'walter', 'white', 1, NOW(), NOW());