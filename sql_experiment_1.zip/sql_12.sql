update customer
set last_update = NOW()
where customer_id = 600;

insert rental (rental_date, inventory_id, customer_id, return_date, staff_id)
values (now(), 1, 600, null, 1);
-- check insert result
select c.customer_id, c.first_name, c.last_name, r.rental_id
from customer as c
inner join rental as r on c.customer_id = r.customer_id
where c.customer_id = 601;