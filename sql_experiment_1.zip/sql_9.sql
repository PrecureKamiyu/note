select f.film_id AS film_id
from film AS f
inner join inventory AS i ON f.film_id = i.film_id
where not exists (
    select *
    from rental AS r
    where r.return_date is null and i.inventory_id = r.inventory_id
) 
or not exists(
    select *
    from rental AS r
    where r.inventory_id = r.inventory_id
)
group by f.film_id
having count(distinct i.store_id) = 2;