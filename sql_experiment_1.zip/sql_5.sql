select a.first_name AS first_name
, a.last_name AS last_name
, count(f.film_id) AS total_films
from actor AS a
inner join film_actor AS fa ON a.actor_id = fa.actor_id
inner join film AS f ON fa.film_id = f.film_id
group by a.actor_id
having count(f.film_id) > 40
order by count(f.film_id) DESC;