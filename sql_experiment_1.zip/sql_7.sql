select a.first_name AS first_name
, a.last_name AS last_name
from actor AS a
inner join film_actor AS fa ON a.actor_id = fa.actor_id
inner join film AS f ON fa.film_id = f.film_id
where f.title = 'ELEPHANT TROJAN' or f.title = 'DOGMA FAMILY'
group by a.actor_id
having count(f.film_id) = 2;