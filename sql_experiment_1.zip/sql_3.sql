select c.first_name, c.last_name, sum(p.amount)
from customer as c
inner join payment as p on c.customer_id = p.customer_id
group by c.customer_id
having sum(p.amount) > 160 and sum(p.amount) < 170;